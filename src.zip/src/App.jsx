import SeatMap from "./components/SeatMap";
import SelectedTable from "./components/SelectedTable";
import Legend from "./components/Legend";

export default function App() {
  return (
    <div className="min-h-screen bg-black text-white">
      <h1 className="text-3xl text-center text-yellow-400 font-bold py-5">
        ĐẶT VÉ XEM PHIM CYBERLEARN.VN
      </h1>
      <div className="container mx-auto grid grid-cols-1 lg:grid-cols-3 gap-6 px-4">
        <div className="lg:col-span-2">
            <p className="text-center">Màn Hình</p>
          <div className="bg-orange-400 h-5 rounded-t-md mb-4"></div>
          <SeatMap />
          <Legend />
        </div>
        <div>
          <h2 className="text-2xl text-center font-bold mb-4">
            DANH SÁCH GHẾ BẠN CHỌN
          </h2>
          <SelectedTable />
        </div>
      </div>
    </div>
  );
}
