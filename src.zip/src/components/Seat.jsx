const Seat = ({ seat, isSelected, toggleSeat }) => {
  const baseClass = "w-10 h-10 m-1 rounded";
  const className = seat.daDat
    ? `${baseClass} bg-gray-400 cursor-not-allowed`
    : isSelected
    ? `${baseClass} bg-green-500`
    : `${baseClass} bg-white hover:bg-yellow-300`;

  return (
    <button
      className={className}
      disabled={seat.daDat}
      onClick={() => toggleSeat(seat)}
    >
      {seat.soGhe}
    </button>
  );
};

export default Seat;
