import Seat from "./Seat";

export default function SeatRow({ rowChar }) {
  const seatNumbers = Array.from({ length: 12 }, (_, i) => i + 1);
  return (
    <div className="flex items-center gap-2">
      <span className="w-6 text-center font-semibold">{rowChar}</span>
      <div className="flex gap-2">
        {seatNumbers.map((n) => (
          <Seat key={n} number={n} />
        ))}
      </div>
    </div>
  );
}
