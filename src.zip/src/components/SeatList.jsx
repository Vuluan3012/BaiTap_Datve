import data from "../data/seatList.json";
import Seat from "./Seat";

const SeatList = ({ selectedSeats, setSelectedSeats }) => {
  const toggleSeat = (seat) => {
    const exists = selectedSeats.find((s) => s.soGhe === seat.soGhe);
    if (exists) {
      setSelectedSeats(selectedSeats.filter((s) => s.soGhe !== seat.soGhe));
    } else {
      setSelectedSeats([...selectedSeats, seat]);
    }
  };

  return (
    <div className="space-y-2">
      {data.map((row, idx) => (
        <div key={idx}>
          <span className="inline-block w-5 font-bold">{row.hang}</span>
          {row.danhSachGhe.map((seat, i) => (
            <Seat
              key={i}
              seat={seat}
              isSelected={selectedSeats.some((s) => s.soGhe === seat.soGhe)}
              toggleSeat={toggleSeat}
            />
          ))}
        </div>
      ))}
    </div>
  );
};

export default SeatList;
