import SeatRow from "./SeatRow";

export default function SeatMap() {
  const rows = "ABCDEFGHIJ".split("");
  return (
    <div className="flex flex-col items-center gap-1">
      {/* Dãy số ghế phía trên */}
      <div className=" flex gap-2 mb-2">
        <span className="w-6" /> {/* chừa ô cho chữ A, B, C... */}
        {Array.from({ length: 12 }, (_, i) => (
          <span key={i} className="w-10 text-center font-semibold">
            {i + 1}
          </span>
        ))}
      </div>

      {/* Các hàng ghế */}
      {rows.map((row) => (
        <SeatRow key={row} rowChar={row} />
      ))}
    </div>
  );
}
