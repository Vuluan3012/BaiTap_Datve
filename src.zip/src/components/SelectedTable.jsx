export default function SelectedTable() {
  const mockSeats = [
    { id: "A1", price: 150000 },
    { id: "A2", price: 150000 },
    { id: "A3", price: 150000 },
  ];
  const total = mockSeats.reduce((t, s) => t + s.price, 0);

  return (
    <div>
      <table className="w-full text-left text-sm border border-white">
        <thead>
          <tr className="bg-gray-700">
            <th className="p-2 border border-white">Số ghế</th>
            <th className="p-2 border border-white">Giá</th>
            <th className="p-2 border border-white">Huỷ</th>
          </tr>
        </thead>
        <tbody>
          {mockSeats.map((seat) => (
            <tr key={seat.id}>
              <td className="p-2 border border-white">{seat.id}</td>
              <td className="p-2 border border-white">{seat.price.toLocaleString("vi-VN")}</td>
              <td className="p-2 border border-white text-center">❌</td>
            </tr>
          ))}
        </tbody>
      </table>
      <div className="flex justify-between font-bold mt-2">
        <span>Tổng tiền</span>
        <span>{total.toLocaleString("vi-VN")}</span>
      </div>
    </div>
  );
}