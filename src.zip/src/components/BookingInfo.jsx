const BookingInfo = ({ selectedSeats }) => {
  const total = selectedSeats.reduce((sum, seat) => sum + seat.gia, 0);

  return (
    <div className="p-4 bg-white rounded shadow">
      <h2 className="text-lg font-bold mb-2">Booking Info</h2>
      <ul className="text-sm">
        {selectedSeats.map((seat, idx) => (
          <li key={idx}>
            Seat {seat.soGhe} - {seat.gia.toLocaleString()} VND
          </li>
        ))}
      </ul>
      <hr className="my-2" />
      <p className="font-semibold">Total: {total.toLocaleString()} VND</p>
      <button
        className="mt-2 px-4 py-2 bg-blue-500 text-white rounded"
        onClick={() => alert("Booking successful!")}
      >
        Confirm
      </button>
    </div>
  );
};

export default BookingInfo;
