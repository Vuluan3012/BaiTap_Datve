export default function Legend() {
  return (
    <div className="mt-4 right-2 flex gap-4 text-sm">
      <div className="flex items-center gap-2">
        <div className="w-4 h-4 rounded bg-yellow-400 border border-black"></div>
        Ghế đã đặt
      </div>
      <div className="flex items-center gap-2">
        <div className="w-4 h-4 rounded bg-green-500 border border-black"></div>
        Ghế đang chọn
      </div>
      <div className="flex items-center gap-2">
        <div className="w-4 h-4 rounded bg-white border-2 border-black"></div>
        Ghế chưa đặt
      </div>
    </div>
  );
}